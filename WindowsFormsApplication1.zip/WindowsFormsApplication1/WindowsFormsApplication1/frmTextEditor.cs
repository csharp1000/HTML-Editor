﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
namespace WindowsFormsApplication1
{
    public partial class frmTextEditor : Form
    {
        StreamReader sr;
        StreamWriter sw;
        string spath;
        public frmTextEditor()
        {

            InitializeComponent();
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            String text = "";
            openFileDialog1 .Filter="Text File(*.txt)|*.txt|All File(*.*)|*.*";
            openFileDialog1.InitialDirectory = @"E:\";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                this.Text = openFileDialog1.FileName + "- Html Editor";
                sr = new StreamReader(openFileDialog1.FileName.ToString());
                text = sr.ReadToEnd();
                txtEditor.Text = text;
                sr.Close();
            }
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFile();
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (txtEditor.Text.ToString() == "")
            {
                txtEditor.Clear();
                String text = "";
                sr = new StreamReader(spath + @"\HtmlNew.txt");
                text = sr.ReadToEnd();
                txtEditor.Text = text;
                sr.Close();
            }
            else
            {
                if (MessageBox.Show("Do you want to save?", "Save?", MessageBoxButtons.OKCancel) == DialogResult.OK)
                {
                    SaveFile();
                    txtEditor.Clear();
                    String text = "";
                    sr = new StreamReader(spath + @"\HtmlNew.txt");
                    text = sr.ReadToEnd();
                    txtEditor.Text = text;
                    sr.Close();
                }
            }
        }
        public void SaveFile()
        {
            String text = "";
            saveFileDialog1.Filter = "Text File(*.txt)|*.txt|All File(*.*)|*.*";
            saveFileDialog1.InitialDirectory = @"E:\";
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                sw = new StreamWriter(saveFileDialog1.FileName);
                text = txtEditor.Text.ToString();
                sw.Write(text);
                sw.Close();
            }

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFile();
        }

        private void exitToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void fontToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fontDialog1.ShowDialog() == DialogResult.OK)
            {
                Font font = fontDialog1.Font;
                this.txtEditor.Font = font;
            }
        }

        private void frmTextEditor_Load(object sender, EventArgs e)
        {
            spath = System.Reflection.Assembly.GetEntryAssembly().Location;
            spath = new FileInfo(spath).Directory.ToString();
        }
        private void headingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            String text = "   ";
            sr = new StreamReader(spath + @"\Heading.txt");
            text = sr.ReadToEnd();
            txtEditor.AppendText(text);
            sr.Close();
        }

        private void paragraphToolStripMenuItem_Click(object sender, EventArgs e)
        {
            String text = "";
            sr = new StreamReader(spath + @"\Paragraph.txt");
            text = sr.ReadToEnd();
            txtEditor.AppendText(text);
            sr.Close();
        }

        private void titleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            String text = "";
            sr = new StreamReader(spath + @"\Title.txt");
            text = sr.ReadToEnd();
            txtEditor.AppendText(text);
            sr.Close();
        }

        private void hyperLinkToolStripMenuItem_Click(object sender, EventArgs e)
        {
            String text = "";
            sr = new StreamReader(spath + @"\HyperLink.txt");
            text = sr.ReadToEnd();
            txtEditor.AppendText(text);
            sr.Close();
        }

        private void imageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            String text = "";
            sr = new StreamReader(spath + @"\Image.txt");
            text = sr.ReadToEnd();
            txtEditor.AppendText(text);
            sr.Close();
        }
    }
}
